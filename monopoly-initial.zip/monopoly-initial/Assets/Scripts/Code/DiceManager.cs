using System.Collections;
using System.Collections.Generic;
using Code;
using UnityEngine;
using UnityEngine.UI;

public class DiceManager : MonoBehaviour
{
    public Button rollButton;
    public Text resultText;
    public GameObject resultPanel;
    public DiceCheckZoneScript checkZone;
    [SerializeField]private GameObject dicePrefab1; // Assigned in the Unity Inspector or load dynamically
    [SerializeField]private GameObject dicePrefab2; // Assigned in the Unity Inspector or load dynamically

    public bool rolling;
    private PlayerManager playerManager;
    void Start()
    {
        rolling = false;
        resultPanel.SetActive(false);
        rollButton.onClick.AddListener(RollDice); // Attach button click event

        playerManager = FindFirstObjectByType<PlayerManager>(); // Reference PlayerManager
    }
    
    public void DestroyUnusedDice()
    {
        foreach (DiceScript dice in checkZone.diceList)
        {
            dice.gameObject.SetActive(false);
            if (dice != null) // Check if the dice object is not null
            {
                Destroy(dice.gameObject); // Destroy the dice GameObject
            }
        }
    }
    public void SpawnDice()
    {
        checkZone.diceList.Clear();

        // Instantiate the dice
        GameObject dice1 = Instantiate(dicePrefab1, new Vector3(0, 5, -5), Quaternion.identity);
        GameObject dice2 = Instantiate(dicePrefab2, new Vector3(0, 5, 5), Quaternion.identity);

        // Log the dice names to confirm they are instantiated
        Debug.Log($"Instantiating new dice: {dice1.name}, {dice2.name}");

        // Add dice to the list for further reference
        checkZone.diceList.Add(dice1.GetComponent<DiceScript>());
        checkZone.diceList.Add(dice2.GetComponent<DiceScript>());
        
    }

    public bool RolledDoubles()
    {
        if (checkZone.diceList.Count < 2) return false;
        int firstRoll = checkZone.diceList[0].currentNumber;
        int secondRoll = checkZone.diceList[1].currentNumber;

        if ((int)firstRoll == (int)secondRoll)
            Debug.Log($"Dice Values rolled Doubles: Dice1 {firstRoll}, Dice2 {secondRoll}");
        
        return firstRoll == secondRoll; // Check for doubles
    }

    public void RollDice()
    {
        if (rolling) return;

        rolling = true;
        rollButton.gameObject.SetActive(false); // Disable button during dice roll

        RollAllDice();
        StartCoroutine(WaitForDiceToSettle());
        // If rolled doubles == true then the same player needs to roll again and move again.
    }
    
    public void RollAllDice()
    {
        foreach (DiceScript dice in checkZone.diceList)
        {
            dice.Roll();
        }
    }

    private IEnumerator WaitForDiceToSettle()
    {
        yield return new WaitUntil(AllDiceStationary);
        checkZone.CheckAndUpdateSum(); // Update dice sum after they stop
        
        yield return new WaitForSeconds(6.0f); // Delay before hiding result
        
        DisplayResult();
        playerManager.StartPlayerMovement(checkZone.totalSum); // Notify PlayerManager to move the player
        rolling = false;
    }

    public int GetDiceSum()
    {
        return checkZone.totalSum;
    }

    public bool AllDiceStationary()
    {
        foreach (DiceScript dice in checkZone.diceList)
        {
            if (!dice.IsStationary()) return false;
        }
        return true;
    }

    private void DisplayResult()
    {
        resultPanel.SetActive(true);
        resultText.text = $"Dice Total: {checkZone.totalSum}";
        Invoke(nameof(HideResult), 2f); // Hide result after 2 seconds
    }

    private void HideResult()
    {
        resultPanel.SetActive(false);
    }
}
