public enum PlayerState
    {
        Playing,
        InJail
    }

